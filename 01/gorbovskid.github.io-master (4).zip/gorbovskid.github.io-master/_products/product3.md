---
identifier: RZ-BAB
name: Kinesiology Taping for Rehab
price: 32.95
image: /assets/images/almond.jpg
---
THE ULTIMATE DIY TAPING GUIDE OF EVERYDAY INJURIES AND AILMENTS INCLUDES OVER 200 STEP-BY-STEP PHOTOS

Widely used by physical therapists, chiropractors and personal trainers, kinesiology tape provides incredible support while simultaneously stretching so your body can perform its normal range of motion. Now you can utilize this amazing material at home. Simply buy a roll at your local drugstore and follow the taping methods described in this book to reduce pain, rehab an injury and get back in the game.

Providing clear step-by-step instructions and helpful photos, the author shows how to tape the most common injuries and conditions anywhere on the body
